package net.androidbootcamp.cityguide;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Water extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water);
    }
}