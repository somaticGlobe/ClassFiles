package net.androidbootcamp.charactergenerator;

public class Cleric extends CharClass
{
    int channelCount;
    double destroyUndead;
    int spellsPrepped;
    public Cleric(Character c)
    {
        name = "Cleric";
        classLvl = 0;
        hd = 8;
        castorType = 1;
        spellSave = 8 + (int)c.getWisBonus() + c.getPB();
        hitDieCount = classLvl;
        //TODO do cantrip function

    }
    public void levelUp(Character c)
    {
        classLvl++;
        ASI(c);
        channelDivinityCalc();
        destroyUndeadCalc();
        spellsPrepped(c);

        double classCastorLvl = Math.round(c.getCastorLvl() + castorType);
        c.setCastorLvl((int)classCastorLvl);

        if(classLvl == 1 && c.getLvl() == 1)
        {
            // Makes Wisdom and Charisma Proficient
            Skill save1 = c.getSaves(4);
            save1.makeProficient();
            c.setSaves(4, save1);

            Skill save2 = c.getSaves(5);
            save2.makeProficient();
            c.setSaves(5, save2);
            //TODO have user choose 2 skills to be proficient in from History, Insight, Medicine, Persuasion, and Religion
        }
        if(classLvl == 1)
        {
            //TODO Subclass
        }
        if(classLvl == 2)
        {
            //TODO subclass Feature
        }
        if(classLvl == 10)
        {
            //TODO Divine Intervention
        }
        if(classLvl == 17)
        {
            //TODO Subclass Feature
        }
        if(classLvl == 20)
        {
            //TODO Divine Intervention
        }
    }
    public void increaseHPRandom(Character c)
    {
        double increase = 1+ (Math.random() * hd);
        int hp = c.getHP() + (int)increase + (int)c.getConBonus();
        c.setHP(hp);
    }
    public void increaseHPFixed(Character c)
    {
        int hp = c.getHP() + 5 + (int)c.getConBonus();
        c.setHP(hp);
    }
    public void ASI(Character c)
    {
        if(classLvl == 4 || classLvl == 8
                || classLvl == 12 || classLvl == 16
                || classLvl == 19)
        {
            //TODO make this do something
        }
    }
    void subClassProgression()
    {
        //TODO Arcana Domain
        //TODO Death Domain
        //TODO Forge Domain
        //TODO Grave Domain
        //TODO Knowledge Domain
        //TODO Life Domain
        //TODO Light Domain
        //TODO Nature Domain
        //TODO Order Domain
        //TODO Peace Domain
        //TODO Tempest Domain
        //TODO Trickery Domain
        //TODO Twilight Domain
        //TODO War Domain
    }
    private void channelDivinityCalc()
    {
        if(classLvl < 2)
        {
            channelCount = 0;
        }
        else if(classLvl < 6)
        {
            channelCount = 1;
        }
        else if(classLvl < 18)
        {
            channelCount = 2;
        }
        else
        {
            channelCount = 3;
        }
    }

    private void destroyUndeadCalc()
    {
        if(classLvl < 5)
        {
            destroyUndead = 0;
        }
        else if(classLvl < 8)
        {
            destroyUndead = 0.5;
        }
        else if(classLvl < 11)
        {
            destroyUndead = 1;
        }
        else if(classLvl < 14)
        {
            destroyUndead = 2;
        }
        else if(classLvl < 17)
        {
            destroyUndead = 3;
        }
        else
        {
            destroyUndead = 4;
        }
    }

    private void spellsPrepped(Character c)
    {
        spellsPrepped = classLvl + (int)c.getWisBonus();
    }
}
