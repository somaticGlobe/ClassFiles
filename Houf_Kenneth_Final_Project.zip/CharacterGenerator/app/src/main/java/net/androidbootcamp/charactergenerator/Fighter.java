package net.androidbootcamp.charactergenerator;

public class Fighter extends CharClass
{
    int actionSurgeCount;
    int extraAttackCount;
    int indomitableTracker;
    public Fighter(Character c)
    {
        name = "Fighter";
        classLvl = 0;
        hd = 10;
        castorType = 0;
        spellSave = 0;
        cantripCount = 0;
        hitDieCount = 0;
        actionSurgeCount = 0;
        extraAttackCount = 0;

    }
    public void levelUp(Character c)
    {
        classLvl ++;
        hitDieCount ++;
        ASI(c);
        subClassProgression();
        actionSurgeCount();
        extraAttackCount();

        if(classLvl == 1 && c.getLvl() == 1)
        {
            // Makes Strength and Constitution Proficient
            Skill save1 = c.getSaves(0);
            save1.makeProficient();
            c.setSaves(0, save1);

            Skill save2 = c.getSaves(2);
            save2.makeProficient();
            c.setSaves(2, save2);
            //TODO have user choose 2 skills to be proficient in from Acrobatics, Animal Handling,
            // Athletics, History, Insight, Intimidation, Perception, Survival
        }
        if(classLvl == 1)
        {
            //TODO fighting Style
            //TODO Second Wind
        }

    }
    public void increaseHPRandom(Character c)
    {

    }
    public void increaseHPFixed(Character c)
    {

    }
    public void ASI(Character c)
    {
        if(classLvl == 4 || classLvl == 6|| classLvl == 8
                || classLvl == 10 || classLvl == 12 || classLvl == 14 ||
                classLvl == 16 || classLvl == 19)
        {
            //TODO make this do something
        }
    }
    public void subClassProgression()
    {
        //TODO Arcane Archer
        //TODO Battle Master
        //TODO Cavalier
        //TODO Champion
        //TODO Echo Knight
        //TODO Eldritch Knight
        //TODO Gunslinger
        //TODO Psi Warrior
        //TODO Purple Dragon Knight
        //TODO Rune Knight
        //TODO Samurai
    }

    private void actionSurgeCount()
    {
        if(classLvl < 2)
        {
            actionSurgeCount = 0;
        }
        else if(classLvl < 17)
        {
            actionSurgeCount =1;
        }
        else
        {
            actionSurgeCount = 2;
        }
    }

    private void extraAttackCount()
    {
        if(classLvl < 5)
        {
           extraAttackCount = 0;
        }
        else if (classLvl < 11)
        {
            extraAttackCount = 1;
        }
        else if(classLvl < 20)
        {
            extraAttackCount = 2;
        }
        else
        {
            extraAttackCount = 3;
        }
    }

    private void indomitableTrackerCalc()
    {
        if(classLvl < 9)
        {
            indomitableTracker = 0;
        }
        else if(classLvl == 9)
        {
            indomitableTracker = 1;
        }
    }
}
