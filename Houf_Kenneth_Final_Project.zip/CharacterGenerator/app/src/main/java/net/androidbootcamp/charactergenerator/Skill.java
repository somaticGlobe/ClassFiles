package net.androidbootcamp.charactergenerator;

public class Skill
{
   private boolean proficiency;
   private int skillBonus;
   private String name;
   private int profBonus;
   private int extraBonus;
   private boolean expertise;
   private boolean halfProficient;
   private int halfPB;

    public Skill(String sName, int bonus, boolean prof, int i)
    {
        name = sName;
        proficiency = prof;
        profBonus = i;
        extraBonus = 0;
        expertise = false;
        halfProficient = false;
        halfPB = (int)Math.floor(i/2);

        if(proficiency)
        {
            skillBonus = bonus + profBonus +extraBonus;
            if(expertise)
            {
                skillBonus = bonus + (profBonus *2) + extraBonus;
            }
        }
        else
        {
            skillBonus = bonus;
            if(halfProficient)
            {
                skillBonus = bonus + halfPB;
            }
        }
    }

    public boolean getProficiency()
    {
        return proficiency;
    }
    public void makeProficient()
    {
        proficiency = true;
    }
    public void makeNotProficient()
    {
        proficiency = false;
    }
    public void makeHalfProficient()
    {
        halfProficient = true;
    }

    public void makeExpert()
    {
        expertise = true;
    }

    public void setExtraBonus(int i)
    {
        extraBonus = i;
    }

    public String getName()
    {
        return name;
    }
    public int getSkillBonus()
    {
        return skillBonus;
    }
}
