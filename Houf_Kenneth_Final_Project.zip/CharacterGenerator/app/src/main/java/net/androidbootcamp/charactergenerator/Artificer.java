package net.androidbootcamp.charactergenerator;

public class Artificer extends CharClass
{
    int infusions;
    int itemsInfused;

    public Artificer(Character c)
    {
        name = "Artificer";
        classLvl = 0;
        hd = 8;
        castorType = 0.5;
        cantripCount = 2;
        hitDieCount = classLvl;
        itemsInfused = infusions / 2;
    }

    // levels up the class chosen
    public void levelUp(Character c)
    {
        classLvl++;
        cantripCalc();
        infusionCalc();
        ASI(c);
        itemsInfused = infusions / 2;

        double classCastorLvl = Math.round(c.getCastorLvl() + castorType);
        c.setCastorLvl((int)classCastorLvl);

        if(classLvl == 1 && c.getLvl() == 1)
        {
            // Makes Constitution and Intelligence Proficient
            Skill save1 = c.getSaves(2);
            save1.makeProficient();
            c.setSaves(2, save1);

            Skill save2 = c.getSaves(3);
            save2.makeProficient();
            c.setSaves(3, save2);
            //TODO have user choose 2 skills to be proficient in from Arcana, History, Investigation, Medicine, Nature, Perception, Sleight of Hand
            //TODO add tool, weapon, and armor proficiencies
        }
        else if(classLvl == 1 && c.getLvl() != 1)
        {
            //TODO add proficiencies for Light Armor, Medium Armor, Shields, Thieve's Tools, and Tinker's Tools
        }

        if(classLvl == 1)
        {
            //TODO add proficiencies and Magical Tinkering
        }

        if(classLvl == 3)
        {
            //TODO add subclass
            //TODO add Right Tool for the Job
        }

        if(classLvl == 5)
        {
            //TODO add Subclass Feature
        }

        if(classLvl == 6)
        {
            //TODO add Tool Expertise
        }

        if(classLvl == 7)
        {
            //TODO add Flash of Genius
        }

        if(classLvl == 9)
        {
            //TODO add Subclass Feature
        }

        if(classLvl == 10)
        {
            //TODO add Magic Item Adept
        }

        if(classLvl == 11)
        {
            //TODO add Spell Storing Item
        }

        if(classLvl == 14)
        {
            // TODO add magic Item Savant
        }

        if(classLvl == 15)
        {
            //TODO add subclass feature
        }

        if(classLvl == 18)
        {
            //TODO add Magic Item Master
        }

        if(classLvl == 20)
        {
            //TODO add Soul of Artifice
        }

    }

    public void increaseHPRandom(Character c)
    {
        double increase = 1+ (Math.random() * hd);
        int hp = c.getHP() + (int)increase + (int)c.getConBonus();
        c.setHP(hp);
    }

    public void increaseHPFixed(Character c)
    {
        int hp = c.getHP() + 5 + (int)c.getConBonus();
        c.setHP(hp);
    }

    public void ASI(Character c)
    {
        if(classLvl == 4 || classLvl == 8
                || classLvl == 12 || classLvl == 16
                || classLvl == 19)
        {
            //TODO make this do something
        }
    }

    public void cantripCalc()
    {
        if(classLvl < 10)
        {
            cantripCount = 2;
        }
        else if (classLvl < 14)
        {
            cantripCount = 3;
        }
        else
        {
            cantripCount = 4;
        }
    }

    public void infusionCalc()
    {
        if(classLvl < 2)
        {
            infusions = 0;
        }
        else if(classLvl < 6)
        {
            infusions = 4;
        }
        else if(classLvl < 10)
        {
            infusions = 6;
        }
        else if(classLvl < 14)
        {
            infusions = 8;
        }
        else if(classLvl < 18)
        {
            infusions = 10;
        }
        else
        {
            infusions = 12;
        }
    }

    void subClassProgression()
    {
        //TODO Alchemist
        //TODO Armorer
        //TODO Artillerist
        //TODO Battle Smith
    }
}
