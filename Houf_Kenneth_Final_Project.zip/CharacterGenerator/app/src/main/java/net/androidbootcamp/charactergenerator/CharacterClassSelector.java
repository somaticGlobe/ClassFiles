package net.androidbootcamp.charactergenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CharacterClassSelector extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_class_selector);

        String[] charClasses = {"Artificer", "Barbarian", "Bard", "Cleric", "Druid", "Fighter",
                                "Monk", "Paladin", "Ranger", "Rogue", "Sorcerer", "Warlock", "Wizard"};
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_character_race_generator, R.id.racesList, charClasses));
    }
}