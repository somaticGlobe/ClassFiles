package net.androidbootcamp.charactergenerator;

public class Barbarian extends CharClass
{
int rageCount;
int rageDamage;
int brutalCritDie;

public Barbarian(Character c)
{
    name = "Barbarian";
    classLvl = 0;
    hd = 12;
    castorType = 0;
    cantripCount = 0;
    hitDieCount = classLvl;
}

    public void levelUp(Character c)
    {
        classLvl++;
        brutalCritDieCalc();
        rageCountCalc();
        rageDamageCalc();
        ASI(c);

        int charLvl = c.getLvl();
        charLvl ++;
        c.setLvl(charLvl);

        if(classLvl == 1 && c.getLvl() == 1)
        {
            // Makes Constitution and Intelligence Proficient
            Skill save1 = c.getSaves(0);
            save1.makeProficient();
            c.setSaves(0, save1);

            Skill save2 = c.getSaves(2);
            save2.makeProficient();
            c.setSaves(2, save2);
            //TODO have user choose 2 skills to be proficient in from Animal Handling, Athletics, Intimidation, Nature, Perception, and Survival
        }
        if(classLvl == 1)
        {
            //TODO add weapon, armor and tool proficiencies
            //TODO add unarmored defence(con)
        }

        if(classLvl ==2)
        {
            //TODO add reckless attack
            //TODO add Danger Sense
        }

        if(classLvl == 3)
        {
            //TODO add Primal Path
        }

        if(classLvl ==5)
        {
            //TODO add Extra Attack
            //TODO add Fast Movement
        }

        if(classLvl == 6)
        {
            //TODO add subclass feature
        }

        if(classLvl == 7)
        {
            //TODO add Feral Instinct
        }
        if(classLvl == 10)
        {
            //TODO add subclass feature
        }

        if(classLvl == 11)
        {
            //TODO relentless rage
        }

        if(classLvl == 14)
        {
            //TODO add subclass Feature
        }

        if(classLvl == 15)
        {
            //TODO add Persistent Rage
        }

        if(classLvl == 18)
        {
            // TODO add indomitable Might
        }

        if(classLvl == 20)
        {
            //TODO add Primal Champion
        }
    }

    public void increaseHPRandom(Character c)
    {
        double increase = 1+ (Math.random() * hd);
        int hp = c.getHP() + (int)increase + (int)c.getConBonus();
        c.setHP(hp);
    }

    public void increaseHPFixed(Character c)
    {
        int hp = c.getHP() + 7 + (int)c.getConBonus();
        c.setHP(hp);
    }

    public void ASI(Character c)
    {
        if(classLvl == 4 || classLvl == 8
                || classLvl == 12 || classLvl == 16
                || classLvl == 19)
        {
            //TODO make this do something
        }
    }

    public void rageCountCalc()
    {
        if(classLvl < 3)
        {
            rageCount = 2;
        }
        else if(classLvl < 6)
        {
            rageCount = 3;
        }
        else if(classLvl < 12)
        {
            rageCount = 4;
        }
        else if(classLvl < 17)
        {
            rageCount = 5;
        }
        else
        {
            rageCount = 6;
        }
    }

    public void rageDamageCalc()
    {
        if(classLvl < 8)
        {
            rageDamage = 2;
        }
        else if(classLvl < 16)
        {
            rageDamage = 3;
        }
        else
        {
            rageDamage = 4;
        }
    }

    public void brutalCritDieCalc()
    {
        if(classLvl < 9)
        {
            brutalCritDie = 0;
        }
        else if(classLvl < 13)
        {
            brutalCritDie = 1;
        }
        else if(classLvl < 17)
        {
            brutalCritDie = 2;
        }
        else
        {
            brutalCritDie = 3;
        }
    }

    void subClassProgression()
    {
        //TODO Ancestral Guardian
        //TODO Battlerager
        //TODO Beast
        //TODO Berserker
        //TODO Storm Herald
        //TODO Totem Warrior
        //TODO Wild Magic
        //TODO Zealot
    }
}
