package net.androidbootcamp.charactergenerator;

public class Wizard extends CharClass
{
    public void levelUp(Character c)
    {

    }
    public void increaseHPRandom(Character c)
    {

    }
    public void increaseHPFixed(Character c)
    {

    }
    public void ASI(Character c)
    {

    }
    public void subClassProgression()
    {

    }
}
