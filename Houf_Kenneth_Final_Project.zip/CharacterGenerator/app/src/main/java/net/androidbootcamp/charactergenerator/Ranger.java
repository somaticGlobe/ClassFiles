package net.androidbootcamp.charactergenerator;

public class Ranger extends CharClass
{
    public void levelUp(Character c)
    {

    }
    public void increaseHPRandom(Character c)
    {

    }
    public void increaseHPFixed(Character c)
    {

    }
    public void ASI(Character c)
    {

    }
    public void subClassProgression()
    {

    }
}
