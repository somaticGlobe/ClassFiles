package net.androidbootcamp.charactergenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Start extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        //Button instantiation
        Button newChar = (Button)findViewById(R.id.btnNewChar);
        Button loadChar = (Button)findViewById(R.id.btnLoadChar);
        Button loadDatabase = (Button)findViewById(R.id.btnDatabase);

        //Listeners
        newChar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(Start.this, CreateNewCharacter.class));
            }
        });

        loadChar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(Start.this, LoadCharacter.class));
            }
        });

        loadDatabase.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //TODO start Database activity
            }
        });
    }
}