package net.androidbootcamp.charactergenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CreateNewCharacter extends AppCompatActivity {
public static Character c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_character);
        c = new Character();

        Button goBack = (Button)findViewById(R.id.btnBack);
        Button charCreator = (Button)findViewById(R.id.btnCharCreator);
        Button scratchCharacter = (Button)findViewById(R.id.btnScratchChar);

        goBack.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(CreateNewCharacter.this, Start.class));
            }
        });

        charCreator.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(CreateNewCharacter.this, CharacterRaceGenerator.class));
            }
        });

        scratchCharacter.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(CreateNewCharacter.this, MainActivity.class));
            }
        });
    }
}