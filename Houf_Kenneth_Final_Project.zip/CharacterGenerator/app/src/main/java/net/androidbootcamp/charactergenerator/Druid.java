package net.androidbootcamp.charactergenerator;

public class Druid extends CharClass
{
    double wildshapeDifficulty;
    public Druid(Character c)
    {
        name = "Druid";
        classLvl = 0;
        hd = 8;
        castorType = 1;
        spellSave = 8 + (int)c.getWisBonus() + c.getPB();
        cantripCount = 2;
        hitDieCount = classLvl;
    }
    public void levelUp(Character c)
    {
        classLvl++;
        ASI(c);
        cantripCalc();
        wildShapeCalc();
        subClassProgression();

        double classCastorLvl = Math.round(c.getCastorLvl() + castorType);
        c.setCastorLvl((int)classCastorLvl);

        if(classLvl == 1 && c.getLvl() == 1)
        {
            // Makes Intelligence and Wisdom Proficient
            Skill save1 = c.getSaves(3);
            save1.makeProficient();
            c.setSaves(3, save1);

            Skill save2 = c.getSaves(4);
            save2.makeProficient();
            c.setSaves(4, save2);
            //TODO have user choose 2 skills to be proficient in from Arcana, Animal Handling, Insight, Medicine, Nature, Perception, Religion
        }
        if(classLvl == 1)
        {
            //TODO add proficiencies
            //TODO add druidic
        }
        if(classLvl == 18)
        {
            //TODO Timeless Body
        }
        if(classLvl ==20)
        {
            //TODO Archdruid
        }


    }
    public void increaseHPRandom(Character c)
    {
        double increase = 1+ (Math.random() * hd);
        int hp = c.getHP() + (int)increase + (int)c.getConBonus();
        c.setHP(hp);
    }
    public void increaseHPFixed(Character c)
    {
        int hp = c.getHP() + 5 + (int)c.getConBonus();
        c.setHP(hp);
    }
    public void ASI(Character c)
    {
        if(classLvl == 4 || classLvl == 8
                || classLvl == 12 || classLvl == 16
                || classLvl == 19)
        {
            //TODO make this do something
        }
    }
    void subClassProgression()
    {
        //TODO Circle of Dreams
        //TODO Circle of Spores
        //TODO Circle of Stars
        //TODO Circle of the Land
        //TODO Circle of the Moon
        //TODO Circle of the Shepherd
        //TODO Circle of Wildfire
    }

    private void cantripCalc()
    {
        if(classLvl < 4)
        {
            cantripCount = 2;
        }
        else if (classLvl < 9)
        {
            cantripCount = 3;
        }
        else
        {
            cantripCount = 4;
        }
    }

    private void wildShapeCalc()
    {
        if(classLvl < 2)
        {
            wildshapeDifficulty = 0;
        }
        else if(classLvl < 4)
        {
            wildshapeDifficulty = 0.25;
        }
        else if(classLvl < 8)
        {
            wildshapeDifficulty = 0.5;
        }
        else
        {
            wildshapeDifficulty = 1;
        }
    }
}
