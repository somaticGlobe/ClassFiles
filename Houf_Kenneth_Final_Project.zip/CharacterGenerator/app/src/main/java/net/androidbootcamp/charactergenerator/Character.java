package net.androidbootcamp.charactergenerator;

public class Character
{
    private String name;
    private int lvl;
    private int castorLvl;
    private int hP;
    private int ac;
    private int profBonus;
    private int speed;
    private String race;
    private String subRace;

    private int sSlots1;
    private int sSlots2;
    private int sSlots3;
    private int sSlots4;
    private int sSlots5;
    private int sSlots6;
    private int sSlots7;
    private int sSlots8;
    private int sSlots9;

    private int strength;
    private int dexterity;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int charisma;

    private int strengthBase;
    private int dexterityBase;
    private int constitutionBase;
    private int intelligenceBase;
    private int wisdomBase;
    private int charismaBase;

    private double strBonus;
    private double dexBonus;
    private double conBonus;
    private double intBonus;
    private double wisBonus;
    private double chaBonus;

    private int strengthRacial;
    private int dexterityRacial;
    private int constitutionRacial;
    private int intelligenceRacial;
    private int wisdomRacial;
    private int charismaRacial;

    private Skill[] skillList;
    private Skill[] saves;
    private CharClass[] classes;

    public Character()
    {
        //starting point for every character
        lvl = 0;
        castorLvl = 0;
        profBonus = 2;
        ac = 10 + (int)dexBonus;
        hP = 0;
        speed = 0;
        race = "human";
        subRace = "none";

        sSlots1 = 0;
        sSlots2 = 0;
        sSlots3 = 0;
        sSlots4 = 0;
        sSlots5 = 0;
        sSlots6 = 0;
        sSlots7 = 0;
        sSlots8 = 0;
        sSlots9 = 0;

        // initializations for testing
        strengthBase = 10;
        dexterityBase = 10;
        constitutionBase = 10;
        intelligenceBase = 10;
        wisdomBase = 10;
        charismaBase = 10;

        //stat totals as they accumulate
        strength = strengthBase + strengthRacial;
        dexterity = dexterityBase + dexterityRacial;
        constitution = constitutionBase + constitutionRacial;
        intelligence = intelligenceBase + intelligenceRacial;
        wisdom = wisdomBase + wisdomRacial;
        charisma = charismaBase + charismaRacial;


        // stat bonuses are used in most calcs and are equal to the base stat -10/2 rounded down
        // i.e. if a strength = 12 strBonus = 1,
        strBonus = Math.floor((strength - 10)/2);
        dexBonus = Math.floor((dexterity - 10)/2);
        conBonus = Math.floor((constitution - 10)/2);
        intBonus = Math.floor((intelligence - 10)/2);
        wisBonus = Math.floor((wisdom - 10)/2);
        chaBonus = Math.floor((charisma - 10)/2);

        saves = new Skill[6];
        saves[0] = new Skill("strengthSave", (int)strBonus, false, profBonus);
        saves[1] = new Skill("dexteritySave", (int)dexBonus, false, profBonus);
        saves[2] = new Skill("constitutionSave", (int)conBonus, false, profBonus);
        saves[3] = new Skill("intelligenceSave", (int)intBonus, false, profBonus);
        saves[4] = new Skill("wisdomSave", (int)wisBonus, false, profBonus);
        saves[5] = new Skill("charismaSave", (int)chaBonus, false, profBonus);

        skillList = new Skill[18];
        skillList[0] = new Skill("Acrobatics", (int)dexBonus, false, profBonus);
        skillList[1] = new Skill("Animal Handling", (int)wisBonus, false, profBonus);
        skillList[2] = new Skill("Arcana", (int)intBonus, false, profBonus);
        skillList[3] = new Skill("Athletics", (int)strBonus, false, profBonus);
        skillList[4] = new Skill("Deception", (int)chaBonus, false, profBonus);
        skillList[5] = new Skill("History", (int)intBonus, false, profBonus);
        skillList[6] = new Skill("Insight", (int)wisBonus, false, profBonus);
        skillList[7] = new Skill("Intimidation", (int)chaBonus, false, profBonus);
        skillList[8] = new Skill("Investigation", (int)intBonus, false, profBonus);
        skillList[9] = new Skill("Medicine", (int)wisBonus, false, profBonus);
        skillList[10] = new Skill("Nature", (int)intBonus, false, profBonus);
        skillList[11] = new Skill("Perception", (int)wisBonus, false, profBonus);
        skillList[12] = new Skill("Performance", (int)chaBonus, false, profBonus);
        skillList[13] = new Skill("Persuasion", (int)chaBonus, false, profBonus);
        skillList[14] = new Skill("Religion", (int)intBonus, false, profBonus);
        skillList[15] = new Skill("Slight of Hand", (int)dexBonus, false, profBonus);
        skillList[16] = new Skill("Stealth", (int)dexBonus, false, profBonus);
        skillList[17] = new Skill("Survival", (int)wisBonus, false, profBonus);

        classes = new CharClass[13];
    }

    public String getName() { return name; }
    public void setName(String s) { name = s; }

    public int getLvl() { return lvl; }
    public void setLvl(int i) { lvl = i; }

    public int getCastorLvl() { return castorLvl; }
    public void setCastorLvl(int i) { castorLvl = i; }

    public int getHP() { return hP; }
    public void setHP(int i) { hP = i; }

    public int getPB() {return profBonus;}

    public int getAC()
    {
        return ac;
    }
    public void setAC(int i)
    {
        ac = i;
    }

    public int getSpeed()
    {
        return speed;
    }
    public void setSpeed(int i)
    {
        speed = i;
    }

    public String getRace()
    {
        return race;
    }
    public void setRace(String s)
    {
        race = s;
    }

    public String getSubRace()
    {
        return subRace;
    }
    public void setSubRace(String s)
    {
        subRace = s;
    }

    public int getStrength() { return strengthBase; }
    public void setStrength(int i) { strengthBase = i; }

    public int getStrengthRacialBonus(){return strengthRacial;}
    public void setStrengthRacialBonus(int i){strengthRacial = i;}

    public int getDexterity() { return dexterityBase; }
    public void setDexterity(int i) { dexterityBase = i; }

    public int getDexterityRacialBonus(){return dexterityRacial;}
    public void setDexterityRacialBonus(int i){dexterityRacial = i;}

    public int getConstitution() { return constitutionBase; }
    public void setConstitution(int i) { constitutionBase = i; }

    public int getConstitutionRacialBonus(){return constitutionRacial;}
    public void setConstitutionRacialBonus(int i){constitutionRacial = i;}

    public int getIntelligence() { return intelligenceBase; }
    public void setIntelligence(int i) { intelligenceBase = i; }

    public int getIntelligenceRacialBonus(){return intelligenceRacial;}
    public void setIntelligenceRacialBonus(int i){intelligenceRacial = i;}

    public int getWisdom() { return wisdomBase; }
    public void setWisdom(int i) { wisdomBase = i; }

    public int getWisdomRacialBonus(){return wisdomRacial;}
    public void setWisdomRacialBonus(int i){wisdomRacial = i;}

    public int getCharisma() { return charismaBase; }
    public void setCharisma(int i) { charismaBase = i; }

    public int getCharismaRacialBonus(){return charismaRacial;}
    public void setCharismaRacialBonus(int i){charismaRacial = i;}

    public double getStrBonus(){return strBonus;}

    public double getDexBonus(){return dexBonus;}

    public double getConBonus(){return conBonus;}

    public double getIntBonus(){return intBonus;}

    public double getWisBonus(){return wisBonus;}

    public double getChaBonus(){return chaBonus;}

    public Skill getSaves(int i) { return saves[i]; }
    public void setSaves(int i, Skill s){saves[i] = s;}

    public Skill getSkill(int i){return skillList[i];}
    public void setSkill (int i, Skill s){skillList[i] = s;}

    public void LevelUp(CharClass c)
    {

    }

    void spellSlotCalc()
    {
        switch(castorLvl)
        {
            case 1:
                sSlots1 = 2;
                break;
            case 2:
                sSlots1 = 3;
                break;
            case 3:
                sSlots1 = 4;
                sSlots2 = 2;
                break;
            case 4:
                sSlots1 = 4;
                sSlots2 = 3;
                break;
            case 5:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 2;
                break;
            case 6:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                break;
            case 7:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 1;
                break;
            case 8:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 2;
                break;
            case 9:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 1;
                break;
            case 10:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 2;
                break;
            case 11:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 3;
                sSlots6 = 1;
                break;
            case 13:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 3;
                sSlots6 = 1;
                sSlots7 = 1;
                break;
            case 15:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 3;
                sSlots6 = 1;
                sSlots7 = 1;
                sSlots8 = 1;
                break;
            case 17:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 3;
                sSlots6 = 1;
                sSlots7 = 1;
                sSlots8 = 1;
                sSlots9 = 1;
                break;
            case 19:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 3;
                sSlots6 = 2;
                sSlots7 = 1;
                sSlots8 = 1;
                sSlots9 = 1;
                break;
            case 20:
                sSlots1 = 4;
                sSlots2 = 3;
                sSlots3 = 3;
                sSlots4 = 3;
                sSlots5 = 3;
                sSlots6 = 2;
                sSlots7 = 2;
                sSlots8 = 1;
                sSlots9 = 1;
                break;
            default:
        }
    }
}
