package net.androidbootcamp.charactergenerator;

public class Bard extends CharClass
{
    int spellsKnown;
    int inspirationSize;
    int inspirationCount;
    int songOfRestSize;

    public Bard(Character c)
    {
        name = "Bard";
        classLvl = 0;
        hd = 8;
        castorType = 1;
        spellSave = (int)c.getChaBonus() + 8 + c.getPB();
        cantripCount = 2;

    }

    public void levelUp(Character c)
    {
        classLvl++;

        cantripCalc();
        ASI(c);
        inspirationCalc(c);
        inspirationSizeCalc();
        songOfRestSizeCalc();

        int charLvl = c.getLvl();
        charLvl ++;
        c.setLvl(charLvl);


        double classCastorLvl = Math.round(c.getCastorLvl() + castorType);
        c.setCastorLvl((int)classCastorLvl);

        if(classLvl == 1 && c.getLvl() == 1)
        {
            // Makes Constitution and Intelligence Proficient
            Skill save1 = c.getSaves(1);
            save1.makeProficient();
            c.setSaves(1, save1);

            Skill save2 = c.getSaves(5);
            save2.makeProficient();
            c.setSaves(5, save2);
            //TODO have user choose 3 skills to be proficient in
            //TODO add tool, weapon, and armor proficiencies
        }
        if(classLvl == 1 && c.getLvl() != 1)
        {
            //TODO multiclassing stuff
        }
        if(classLvl == 1)
        {
            //TODO Proficiencies n stuff
            //TODO picking SPells
        }

        if(classLvl == 2)
        {
            //TODO Jack of All Trades
            //TODO song of rest
        }
        if(classLvl == 3)
        {
            //TODO subclass
            //TODO expertise(must be proficient first)
        }
        if(classLvl == 5)
        {
            //TODO Font of Inspiration
        }
        if(classLvl == 6)
        {
            //TODO Countercharm
            //TODO Subclass Feature
        }
        if(classLvl == 10)
        {
            //TODO Expertise
            magicalSecrets();
        }
        if(classLvl == 14)
        {
            magicalSecrets();
            //TODO Subclass Feature
        }
        if(classLvl == 18)
        {
            magicalSecrets();
        }
        if(classLvl == 20)
        {
            //TODO Superior Inspiration
        }
    }

    public void increaseHPRandom(Character c)
    {
        double increase = 1+ (Math.random() * hd);
        int hp = c.getHP() + (int)increase + (int)c.getConBonus();
        c.setHP(hp);
    }

    public void increaseHPFixed(Character c)
    {
        int hp = c.getHP() + 5 + (int)c.getConBonus();
        c.setHP(hp);
    }

    public void ASI(Character c)
    {
        if(classLvl == 4 || classLvl == 8
                || classLvl == 12 || classLvl == 16
                || classLvl == 19)
        {
            //TODO make this do something
        }
    }

    void subClassProgression()
    {
        //TODO College of Creation
        //TODO College of Eloquence
        //TODO College of Glamour
        //TODO College of Lore
        //TODO College of Swords
        //TODO College of Valor
        //TODO College of Whispers
    }

    private void cantripCalc()
    {
        if(classLvl < 4)
        {
            cantripCount = 2;
        }
        else if (classLvl < 9)
        {
            cantripCount = 3;
        }
        else
        {
            cantripCount = 4;
        }
    }

    private void inspirationCalc(Character c)
    {
        inspirationCount = (int)c.getChaBonus();
    }

    private void inspirationSizeCalc()
    {
        if(classLvl < 5)
        {
            inspirationSize = 6;
        }
        else if(classLvl < 10)
        {
            inspirationSize = 8;
        }
        else if(classLvl < 15)
        {
            inspirationSize = 10;
        }
        else
        {
            inspirationSize = 12;
        }
    }

    private void songOfRestSizeCalc()
    {
        if(classLvl < 2)
        {
            songOfRestSize = 0;
        }
        else if(classLvl < 9)
        {
            songOfRestSize = 6;
        }
        else if (classLvl < 13)
        {
            songOfRestSize = 8;
        }
        else if(classLvl < 17)
        {
            songOfRestSize = 10;
        }
        else
        {
            songOfRestSize = 12;
        }
    }

    private void spellsKnown()
    {
        if(classLvl < 2)
        {
            spellsKnown = 4;
            //TODO select Spells
        }
        else if(classLvl < 10)
        {
            spellsKnown++;
            //TODO select Spell
            //TODO retrain Spells
        }
        else if(classLvl == 10)
        {
            spellsKnown = 14;
            //TODO Retrain Spells
        }
        else if(classLvl < 13)
        {
            spellsKnown = 15;
            //TODO select spell
            //TODO retrain Spells
        }
        else if(classLvl < 15)
        {
            spellsKnown = 16;
        }
        else
        {
            spellsKnown = 20;
        }

    }

    private void magicalSecrets()
    {
        //TODO grabs spells from other spell lists and puts them into the Bards
        //TODO limited by caster level
    }

}
