package net.androidbootcamp.charactergenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class CharacterRaceGenerator extends ListActivity {

    boolean raceSelected = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_race_generator);

        String[] races = {"Dragonborn", "Dwarf", "Elf","Gnome", "Half-Elf", "Halfling", "Half-Orc", "Human", "Tiefling"};
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_character_race_generator, R.id.racesList, races));
        Button goBack = (Button)findViewById(R.id.btnBackToCharCreator);
        Button home = (Button)findViewById(R.id.btnBack3);
        Button nextStep = (Button)findViewById(R.id.btnClassSelector);

        goBack.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(CharacterRaceGenerator.this, CreateNewCharacter.class));
            }
        });
        home.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(CharacterRaceGenerator.this, Start.class));
            }
        });
        goBack.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(raceSelected)
                {
                     startActivity(new Intent(CharacterRaceGenerator.this, CharacterClassSelector.class));
                }
                else
                {
                    //TODO Display reminder to choose a race
                }
            }
        });
    }

    protected void onListItemClick(ListView l, View v, int position, long id)
    {
        switch(position)
        {
            case 0:
                CreateNewCharacter.c.setStrengthRacialBonus(2);
                CreateNewCharacter.c.setCharisma(1);
                CreateNewCharacter.c.setRace("Dragonborn");
                CreateNewCharacter.c.setSpeed(30);
                raceSelected = true;
                //TODO implement dragon born color choice
                break;
            case 1:
                //TODO implement Dwarf racial bonuses and ask for Dwarven Subclass
                break;
            case 2:
                //TODO implement elf race and ask for els subrace
                break;
            case 3:
                //TODO implement Gnome race and ask for subrace
            case 4:
                //TODO implemet half-Elf race
            case 5:
                //TODO implement halfling race and subraces
            case 6:
                //TODO implement Half-Orc race
            case 7:
                //TODO implement Human Race
            case 8:
                //TODO implement Tiefling race

        }
    }

}