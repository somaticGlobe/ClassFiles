package net.androidbootcamp.charactergenerator;
//Abstract class to hold method definitions for the Different Classes
abstract public class CharClass
{
    protected String name;
    protected int classLvl;
    protected int hd;
    protected double castorType;
    protected int spellSave;
    int cantripCount;
    int hitDieCount;
    String subclass;

    abstract void levelUp(Character c);
    abstract void increaseHPRandom(Character c);
    abstract void increaseHPFixed(Character c);
    abstract void ASI(Character c);
    abstract void subClassProgression();
}
